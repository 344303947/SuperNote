#!/bin/bash

# ==========================================
# 智能笔记管理器 - Linux自动安装脚本
# ==========================================

# 设置颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}智能笔记管理器 - Linux自动安装脚本${NC}"
echo -e "${BLUE}==========================================${NC}"

# 检测系统类型
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
else
    OS=$(uname -s)
fi

echo -e "${GREEN}[INFO] 检测到系统: $OS${NC}"

# 安装Python3和pip
echo -e "${BLUE}[INFO] 检查并安装Python3和pip...${NC}"

if command -v python3 &> /dev/null; then
    echo -e "${GREEN}[INFO] Python3 已安装${NC}"
else
    echo -e "${YELLOW}[INFO] 安装Python3...${NC}"
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        sudo apt update
        sudo apt install -y python3 python3-pip python3-venv
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        sudo yum install -y python3 python3-pip
    elif [[ "$OS" == *"Fedora"* ]]; then
        sudo dnf install -y python3 python3-pip
    elif [[ "$OS" == *"Arch"* ]]; then
        sudo pacman -S python python-pip
    else
        echo -e "${RED}[ERROR] 不支持的系统类型: $OS${NC}"
        echo -e "${YELLOW}[INFO] 请手动安装Python3和pip${NC}"
        exit 1
    fi
fi

# 安装Node.js (如果需要)
if command -v node &> /dev/null; then
    echo -e "${GREEN}[INFO] Node.js 已安装${NC}"
else
    echo -e "${YELLOW}[INFO] 安装Node.js...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# 设置执行权限
echo -e "${BLUE}[INFO] 设置执行权限...${NC}"
chmod +x start.sh

echo -e "${GREEN}[INFO] 安装完成！${NC}"
echo -e "${GREEN}[INFO] 运行 ./start.sh 启动应用${NC}"
echo -e "${GREEN}[INFO] 访问地址: http://127.0.0.1:8000${NC}"
