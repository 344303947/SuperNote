#!/bin/bash

# ==========================================
# 智能笔记管理器 - Linux生产环境启动脚本
# ==========================================

# 设置颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 设置项目根目录
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo -e "${BLUE}[INFO] 智能笔记管理器 - Linux版本${NC}"
echo -e "${BLUE}[INFO] 项目目录: $ROOT${NC}"

# 检查Python环境
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[ERROR] 未找到 Python3，请先安装 Python3。${NC}"
    echo -e "${YELLOW}[INFO] 安装命令: sudo apt install python3 python3-pip (Ubuntu/Debian)${NC}"
    echo -e "${YELLOW}[INFO] 安装命令: sudo yum install python3 python3-pip (CentOS/RHEL)${NC}"
    exit 1
fi

# 检查Python版本
PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo -e "${GREEN}[INFO] Python版本: $PYTHON_VERSION${NC}"

# 检查pip
if ! command -v pip3 &> /dev/null; then
    echo -e "${YELLOW}[WARN] 未找到 pip3，尝试使用 python3 -m pip${NC}"
    PIP_CMD="python3 -m pip"
else
    PIP_CMD="pip3"
fi

# 创建虚拟环境（如果不存在）
if [ ! -d ".venv" ]; then
    echo -e "${BLUE}[INFO] 创建虚拟环境 .venv ...${NC}"
    python3 -m venv .venv
    if [ $? -ne 0 ]; then
        echo -e "${RED}[ERROR] 虚拟环境创建失败${NC}"
        exit 1
    fi
fi

# 激活虚拟环境
echo -e "${BLUE}[INFO] 激活虚拟环境...${NC}"
source .venv/bin/activate

# 升级pip
echo -e "${BLUE}[INFO] 升级pip...${NC}"
python -m pip install --upgrade pip > /dev/null 2>&1

# 安装依赖
echo -e "${BLUE}[INFO] 安装依赖包...${NC}"
python -m pip install -r backend/requirements.txt
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] 依赖安装失败${NC}"
    echo -e "${YELLOW}[INFO] 请检查网络连接或尝试使用国内镜像源${NC}"
    echo -e "${YELLOW}[INFO] 例如: pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r backend/requirements.txt${NC}"
    exit 1
fi

# 检查端口是否被占用
PORT=8000
if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "${YELLOW}[WARN] 端口 $PORT 已被占用，尝试使用端口 8001${NC}"
    PORT=8001
fi

# 启动应用
echo -e "${GREEN}[INFO] 启动智能笔记管理器...${NC}"
echo -e "${GREEN}[INFO] 访问地址: http://127.0.0.1:$PORT${NC}"
echo -e "${GREEN}[INFO] 按 Ctrl+C 停止服务${NC}"
echo

# 启动服务
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port $PORT

# 如果服务异常退出，显示错误信息
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] 服务启动失败${NC}"
    echo -e "${YELLOW}[INFO] 请检查错误信息或联系开发者${NC}"
    read -p "按回车键退出..."
fi
