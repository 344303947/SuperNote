# 智能笔记管理器 - Linux版本 v20250921_1741

## 版本信息
- 版本号: v20250921_1741
- 构建时间: 2025-09-21 17:41:00
- 构建环境: Windows (跨平台打包)
- 目标平台: Linux (Ubuntu/CentOS/Debian/Fedora/Arch)

## 系统要求
- Python 3.8+ (推荐 3.10+)
- pip3
- 网络连接 (用于AI功能)

## 快速安装

### 方法一：自动安装 (推荐)
```bash
# 1. 解压文件
unzip note-ai-manager-linux-v20250921_1741.zip
cd note-ai-manager-linux-v20250921_1741

# 2. 运行自动安装脚本
chmod +x install.sh
./install.sh

# 3. 启动应用
./start.sh
```

### 方法二：手动安装
```bash
# 1. 安装Python3和pip
# Ubuntu/Debian:
sudo apt update
sudo apt install python3 python3-pip python3-venv

# CentOS/RHEL:
sudo yum install python3 python3-pip

# 2. 解压并进入目录
unzip note-ai-manager-linux-v20250921_1741.zip
cd note-ai-manager-linux-v20250921_1741

# 3. 设置执行权限
chmod +x start.sh

# 4. 启动应用
./start.sh
```

## 使用说明

### 启动应用
```bash
./start.sh
```

### 访问应用
- 本地访问: http://127.0.0.1:8000
- 局域网访问: http://[你的IP]:8000

### 停止应用
按 `Ctrl+C` 停止服务

### 后台运行
```bash
# 使用nohup后台运行
nohup ./start.sh > app.log 2>&1 &

# 查看日志
tail -f app.log

# 停止后台服务
pkill -f "uvicorn backend.app.main:app"
```

## 配置说明

### API配置
首次启动后，在浏览器中配置：
- API地址 (Base URL)
- API密钥 (API Key)  
- 模型名称

### 数据存储
- 数据库: `data/notes.db`
- 笔记文件: `notes/` 目录
- 配置文件: 自动生成

## 故障排除

### 常见问题

**1. Python3未安装**
```bash
# Ubuntu/Debian
sudo apt install python3 python3-pip python3-venv

# CentOS/RHEL
sudo yum install python3 python3-pip
```

**2. 依赖安装失败**
```bash
# 使用国内镜像源
pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple -r backend/requirements.txt
```

**3. 端口被占用**
```bash
# 查看端口占用
lsof -i :8000

# 杀死占用进程
sudo kill -9 [PID]
```

**4. 权限问题**
```bash
# 设置执行权限
chmod +x start.sh
chmod +x install.sh

# 设置文件权限
chmod -R 755 .
```

### 日志查看
```bash
# 查看启动日志
./start.sh

# 后台运行日志
tail -f app.log
```

## 功能特性
- AI 自动分析笔记内容并提取分类、标签
- 一键 AI 优化正文并生成标题
- 笔记保存到 SQLite 与本地 Markdown 文件
- 支持全文搜索和条件过滤
- 全屏编辑模式
- 本地运行，无需外网 (AI功能需要网络)

## 技术支持
如有问题，请：
1. 查看本文档的故障排除部分
2. 检查控制台错误信息
3. 联系开发者获取支持

## 更新日志
- v20250921_1741: Linux专用版本发布
- 支持自动安装和依赖管理
- 优化的启动脚本和错误处理
- 完整的Linux系统兼容性
