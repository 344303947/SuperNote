# 部署 GitLab CE 中文版
**分类：** IT运维
**标签：** Docker, GitLab, 中文版

## 部署 GitLab CE 中文版

### 1. 创建独立网络
```bash
docker network create gitlab-net
```

### 2. 部署 GitLab 容器

#### 完整数据卷挂载版本（推荐生产环境）
```bash
sudo docker run -d \
  --hostname gitsu.m.fastnat.top \
  -p 9093:80 \
  -p 443:443 \
  -p 22:22 \
  --name gitlab \
  --restart unless-stopped \
  -v gitlab-config:/etc/gitlab \
  -v gitlab-logs:/var/log/gitlab \
  -v gitlab-data:/var/opt/gitlab \
  --network gitlab-net \
  twang2218/gitlab-ce-zh:latest
```

#### 简化版本（仅挂载配置目录）
```bash
sudo docker run -d \
  --hostname gitsu.m.fastnat.top \
  -p 9093:80 \
  -p 443:443 \
  --name gitlab \
  --restart unless-stopped \
  -v gitlab-config:/etc/gitlab \
  --network gitlab-net \
  twang2218/gitlab-ce-zh:latest
```

### 说明
- `gitlab-config`、`gitlab-logs`、`gitlab-data` 为 Docker 命名卷，自动创建。
- 端口映射 `9093:80` 用于 HTTP 访问，避免与主机 80 端口冲突。
- 建议使用完整版本以确保数据持久化与可维护性。
- 确保主机已开放 80、443、22 端口（若需 SSH 访问）。
- 首次启动需等待几分钟完成初始化，可通过 `docker logs gitlab` 查看进度。