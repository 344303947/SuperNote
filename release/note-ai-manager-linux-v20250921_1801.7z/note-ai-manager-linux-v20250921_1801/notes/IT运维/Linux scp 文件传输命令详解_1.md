# Linux scp 文件传输命令详解
**分类：** IT运维
**标签：** scp, Linux, SSH, 文件传输, 命令行, 网络安全, Windows, 运维工具

# 📘 知识文档图谱：Linux 文件传输 —— `scp` 命令详解

## 1. 核心命令：`scp`

### 🔹 命令全称  
**Secure Copy Protocol** —— 安全复制协议

### 🔹 功能  
在本地主机与远程主机之间，或两台远程主机之间，**安全地复制文件或目录**，基于 SSH 协议加密传输。

### 🔹 优势  
- 加密传输（基于 SSH）  
- 身份认证安全（支持密钥/密码）  
- 无需额外服务（依赖已安装的 SSH 服务）  
- 支持递归复制目录

---

## 2. 命令语法结构

```bash
scp [选项] 源路径 目标路径
```

### 📌 常用格式：

| 类型 | 格式 | 说明 |
|------|------|------|
| 本地 → 远程 | `scp [本地文件] [用户名]@[远程主机]:[远程路径]` | 将本地文件上传到远程服务器 |
| 远程 → 本地 | `scp [用户名]@[远程主机]:[远程路径] [本地路径]` | 从远程服务器下载文件到本地 |
| 远程 → 远程 | `scp [用户1]@[主机1]:[路径1] [用户2]@[主机2]:[路径2]` | 两台远程主机之间直接复制 |

> ✅ 注意：远程路径若为目录，需使用 `-r` 递归选项

---

## 3. 示例解析：你提供的命令

```bash
scp "C:\Users\i_lov\Desktop\ik_install_doc.txt" sean@192.168.0.32:/home/sean/
```

### ✅ 逐部分解析：

| 组成部分 | 含义 |
|----------|------|
| `scp` | 命令本身 |
| `"C:\Users\i_lov\Desktop\ik_install_doc.txt"` | **源文件路径**（Windows 本地路径，使用双引号包裹以防空格解析错误） |
| `sean` | 远程主机的 **SSH 用户名** |
| `192.168.0.32` | 远程主机的 **IP 地址**（局域网内设备） |
| `:/home/sean/` | 远程主机上的 **目标目录**（`:` 前为主机，后为路径） |

### ✅ 操作结果  
将本地 Windows 系统桌面上的 `ik_install_doc.txt` 文件，通过 SSH 安全传输至远程 Linux 服务器（IP: `192.168.0.32`）的用户 `sean` 的家目录 `/home/sean/` 下。

### ⚠️ 注意事项
- **必须确保远程服务器已开启 SSH 服务**（如 `sshd`）
- **需有 `sean` 用户的登录权限**（密码或 SSH 密钥认证）
- 本地为 Windows 时，建议使用 **Windows Terminal + OpenSSH 客户端**（Win10/11 自带）或 **Git Bash / WSL**
- 若路径含空格，必须用双引号包裹

---

## 4. 常用选项速查表

| 选项 | 说明 |
|------|------|
| `-r` | 递归复制整个目录 |
| `-P <端口>` | 指定远程 SSH 服务端口（默认 22）<br>例：`scp -P 2222 file user@host:/path` |
| `-p` | 保留文件的修改时间、访问时间、权限等属性 |
| `-q` | 静默模式，不显示传输进度 |
| `-C` | 启用压缩传输（适用于大文件/慢网络） |
| `-v` | 详细模式，显示调试信息（用于排错） |

### 💡 示例扩展：
```bash
# 递归复制整个文件夹
scp -r "C:\Users\i_lov\Documents\project" sean@192.168.0.32:/home/sean/

# 使用非标准端口 2222 上传
scp -P 2222 file.txt sean@192.168.0.32:/home/sean/

# 保留属性 + 压缩上传
scp -pC "C:\data\largefile.zip" sean@192.168.0.32:/tmp/
```

---

## 5. 相关知识图谱节点（Knowledge Graph Nodes）

```mermaid
graph TD
    A[文件传输] --> B[scp]
    A --> C[rsync]
    A --> D[sftp]
    A --> E[ftp/scp/smb]

    B --> B1[基于SSH]
    B --> B2[加密传输]
    B --> B3[支持跨平台]
    B --> B4[语法类似cp]

    C --> C1[增量同步]
    C --> C2[高效大文件]
    C --> C3[支持断点续传]
    C --> C4[更复杂但更强大]

    D --> D1[交互式文件管理]
    D --> D2[类似FTP界面]
    D --> D3[支持目录浏览]

    B --> E1[Windows客户端支持]
    B --> E2[Linux/macOS原生支持]
    B --> E3[需SSH服务端开启]

    B --> F[常见错误]
    F --> F1[Permission denied: 检查用户权限]
    F --> F2[Connection refused: 检查SSH服务是否运行]
    F --> F3[Host key verification failed: 清除~/.ssh/known_hosts]
    F --> F4[找不到命令: Windows需安装OpenSSH客户端]
```

---

## 6. 实践建议与最佳实践

| 建议 | 说明 |
|------|------|
| ✅ 使用 SSH 密钥登录 | 避免每次输入密码，提升自动化效率 |
| ✅ 避免使用 root 上传 | 使用普通用户 + sudo 权限更安全 |
| ✅ 检查目标路径是否存在 | 如 `/home/sean/` 不存在会报错 |
| ✅ 传输大文件使用 `-C` 压缩 | 减少网络时间 |
| ✅ 使用 `rsync` 替代 `scp` 做同步 | 特别适合频繁更新的目录 |
| ✅ 在 Windows 中推荐使用 WSL 或 Git Bash | 原生命令体验更佳 |

---

## 7. 扩展阅读与工具推荐

| 工具 | 用途 |
|------|------|
| **WinSCP** (Windows GUI) | 图形化 SCP/SFTP 客户端，适合不熟悉命令行用户 |
| **FileZilla** | 支持 SFTP、FTP 多协议 |
| **rsync + SSH** | 高效增量同步，适合备份场景 |
| **SSH Config 文件** (`~/.ssh/config`) | 简化复杂连接（如别名、端口、密钥） |

### 📄 示例 SSH 配置（`~/.ssh/config`）：
```config
Host myserver
    HostName 192.168.0.32
    User sean
    Port 22
    IdentityFile ~/.ssh/id_rsa
```
→ 后续只需：`scp ik_install_doc.txt myserver:/home/sean/`

---

## ✅ 总结：一句话掌握核心

> **`scp` 是 Linux/Unix 系统中基于 SSH 安全传输文件的“瑞士军刀”，语法简洁，跨平台兼容，是运维人员必备技能。**

---

📌 **建议收藏此文档作为日常运维速查手册**  
🔧 下一步可学习：`rsync`、`sftp`、`ssh-keygen` 密钥认证、SSH 隧道

如需生成 PDF 或 Markdown 版本，我可为你格式化输出。是否需要补充“常见错误排查”章节？